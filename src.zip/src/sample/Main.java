package sample;
import javafx.application.Application;
import javafx.geometry.Rectangle2D;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.ImageView;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Screen;
import javafx.stage.Stage;

public class Main extends Application {

    private Stage primaryStage;
    private ImageView imgBg;
    private Button btn;
    private Button btn2;
    private Button btn3;
    private Button btn4;
    private Scene scene;
    private Scene scene2;

    public static void main(String[] args) {
        Application.launch(Main.class, args);
    }

    @Override
    public void start(Stage primaryStage) {
        System.out.println("Notre Interface");
        this.primaryStage = primaryStage;
        ////////////////////////////////////// Titre scene 1 /////////////////////////
        Group sign = new Group();
        sign.setTranslateX(150);
        sign.setTranslateY(200);
        Text text = new Text(150, 350, "LA MUERTE");
        text.setFont(new Font("Indie flower",100));
        text.setFill(Color.WHITE);
///////////////////////////////////// Titre de la fenetre //////////////////////////
        primaryStage.setTitle("NOTRE INTERFACE");
//////////////////////////////////////////////////////// Scene1 /////////////////
        Group root = new Group();
        Scene scene = new Scene(root, 1920, 1080, Color.LIGHTBLUE);
        btn = initButton(750, 100, "Jouer", 90, 30, "Indie flower", 20);
        btn2 = initButton(950, 100, "Options", 90, 30, "Indie flower", 20);
        btn3 = initButton(1150, 100, "Quitter", 90, 30,  "Indie flower", 20);
        ///////////////////////////////////////////// Scene2 //////////////////////
        Group root2 = new Group();
        Scene scene2 = new Scene(root2, 1920, 1080, Color.RED);
        btn4 = initButton(1150, 100, "Quitter", 90, 30,  "Indie flower", 20);


        btn.setOnAction(event -> primaryStage.setScene(scene2));
        btn2.setOnAction(event -> primaryStage.setScene(scene));
        btn3.setOnAction(event -> primaryStage.close());
        /////////////////////////////action pour le deuxieme ecran ///////////////
        btn4.setOnAction(event -> primaryStage.close());
        initBackground();

        // composition des scènes
        //root.getChildren().addAll(imgBg);
        //primaryStage.setFullScreen(true);
        // Taille image identique pour le primary stage les scene doivent etre de meme resolution a specifier/////
        primaryStage.setResizable(true);
        /////////////////////////////////////////////////////////////////
        root.getChildren().add(btn);
        root.getChildren().add(btn2);
        root.getChildren().add(btn3);
        root.getChildren().add(text);
        root2.getChildren().add(btn4);

        // gestion de l'affichage au lancement
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    private void initBackground() {
        imgBg = new ImageView("assets/images/crane.jpeg");
        Rectangle2D primaryScreenBounds = Screen.getPrimary().getBounds(); // Récupération de la taille de l'écran
        imgBg.setFitHeight((int) primaryScreenBounds.getHeight());
        imgBg.setFitWidth((int) primaryScreenBounds.getWidth());
    }

    private Button initButton(int longueur, int largeur, String texteDuBouton, int tailleBoutonLargeur, int tailleBoutonHauteur, String police, int taillePolice){
        // Création d'un bouton
        Button b = new Button();
        b.setLayoutX(longueur);
        b.setLayoutY(largeur);
        b.setText(texteDuBouton);
        b.setFont(new Font(police,taillePolice));
        b.setFont(Font.font(police, FontWeight.BOLD, FontPosture.REGULAR, taillePolice));
        b.setPrefSize(tailleBoutonLargeur, tailleBoutonHauteur);
        return b;
    }
}


