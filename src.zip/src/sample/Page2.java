package sample;

public class Page2 {

}
